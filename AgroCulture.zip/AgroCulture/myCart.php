<?php
session_start();
require 'db.php';

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] == 0) {
    $_SESSION['message'] = "You need to first login to access this page !!!";
    header("Location: Login/error.php");
    exit();
}

$bid = $_SESSION['id'];

/* ------------------------------
   ADD PRODUCT TO CART
--------------------------------*/
if (isset($_GET['flag'])) {
    $pid = $_GET['pid'];

    $sql = "INSERT INTO mycart (bid, pid)
            VALUES ('$bid', '$pid')";
    mysqli_query($conn, $sql);
}

/* ------------------------------
   DELETE PRODUCT FROM CART
--------------------------------*/
if (isset($_GET['delete'])) {
    $delete_pid = $_GET['delete'];

    $sql_delete = "DELETE FROM mycart WHERE bid='$bid' AND pid='$delete_pid'";
    mysqli_query($conn, $sql_delete);

    header("Location: mycart.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AgroCulture: My Cart</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="login.css"/>
    <script src="js/jquery.min.js"></script>
    <script src="js/skel.min.js"></script>
    <script src="js/skel-layers.min.js"></script>
    <script src="js/init.js"></script>
    <noscript>
        <link rel="stylesheet" href="css/skel.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/style-xlarge.css" />
    </noscript>
</head>

<body>

<?php
require 'menu.php';

function dataFilter($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<section id="main" class="wrapper style1 align-center">
    <div class="container">
        <h2>My Cart</h2>

        <section id="two" class="wrapper style2 align-center">
            <div class="container">
                <div class="row">

                <?php
                $sql = "SELECT * FROM mycart WHERE bid='$bid'";
                $result = mysqli_query($conn, $sql);

                while ($row = $result->fetch_array()):
                    $pid = $row['pid'];
                    $sql1 = "SELECT * FROM fproduct WHERE pid='$pid'";
                    $result1 = mysqli_query($conn, $sql1);
                    $row1 = $result1->fetch_array();

                    $picDestination = "images/productImages/" . $row1['pimage'];
                ?>
                    <div class="col-md-4">
                        <section>
                            <strong>
                                <h2 class="title" style="color:black;">
                                    <?php echo $row1['product']; ?>
                                </h2>
                            </strong>

                            <a href="review.php?pid=<?php echo $row1['pid']; ?>">
                                <img class="image fit" src="<?php echo $picDestination; ?>" alt="" />
                            </a>

                            <blockquote>
                                Type: <?php echo $row1['pcat']; ?><br>
                                Price: <?php echo $row1['price']; ?> /-
                            </blockquote>

                            <!-- DELETE BUTTON -->
                            <a href="mycart.php?delete=<?php echo $row1['pid']; ?>" 
                               class="btn btn-danger" style="margin-top: 10px;">
                               Delete
                            </a>
                        </section>
                    </div>
                <?php endwhile; ?>

                </div>

                <!-- PROCEED TO BUY BUTTON -->
                <a href="checkout.php" class="btn btn-success btn-lg" style="margin-top: 30px;">
                    <centre>Proceed to Buy</centre>
                </a>

            </div>
        </section>
    </div>
</section>

</body>
</html>
