<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Determine login/profile link and icon
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
    $loginProfile = "My Profile: " . $_SESSION['Username'];
    $logo = "glyphicon glyphicon-user";
    $link = ($_SESSION['Category'] != 1) ? "Login/profile.php" : "profileView.php";
} else {
    $loginProfile = "Login";
    $link = "index.php";
    $logo = "glyphicon glyphicon-log-in";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AgroCulture</title>
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <style>
        /* Menu styling */
        #header { background-color: #333; padding: 10px; }
        #header ul { list-style: none; margin: 0; padding: 0; display: flex; gap: 15px; }
        #header ul li { display: inline; }
        #header ul li a { color: white; text-decoration: none; font-weight: bold; }
        #header ul li a:hover { color: #ffd700; }
    </style>
</head>
<body>

<header id="header">
    <div class="footer-left">
        <h1 style="font-size:50px; font-family:'Imprint MT Shadow'; color:white;">AgroCulture &copy;</h1>
    </div>

    <nav id="nav">
        <ul>
            <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
            <li><a href="myCart.php"><span class="glyphicon glyphicon-shopping-cart"></span> MyCart</a></li>
            <li><a href="<?= $link; ?>"><span class="<?= $logo; ?>"></span> <?= $loginProfile; ?></a></li>
            <li><a href="market.php"><span class="glyphicon glyphicon-grain"></span> Products</a></li>
            <li><a href="blogView.php"><span class="glyphicon glyphicon-comment"></span> BLOG</a></li>
            <!-- About Us linking to footer -->
            <li><a href="index.php#footer-about"><span class="glyphicon glyphicon-earphone"></span> About Us</a></li>
        </ul>
    </nav>
</header>

<!-- Smooth scrolling script -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Scroll to footer if URL has #footer-about
    if (window.location.hash === "#footer-about") {
        const footer = document.getElementById("footer-about");
        if (footer) {
            footer.scrollIntoView({ behavior: "smooth" });
        }
    }

    // Smooth scroll on clicking About Us link
    document.querySelectorAll('a[href$="#footer-about"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const footer = document.getElementById("footer-about");
            if (footer) {
                e.preventDefault();
                footer.scrollIntoView({ behavior: "smooth" });
                history.pushState(null, null, '#footer-about');
            }
        });
    });
});
</script>

</body>
</html>
